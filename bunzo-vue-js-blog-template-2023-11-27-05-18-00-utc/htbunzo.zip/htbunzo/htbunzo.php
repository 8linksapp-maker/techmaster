<?php
/**
 * Bunzo
 *
 * @package       BUNZO
 * @author        HasThemes
 * @version       1.0.0
 *
 * @wordpress-plugin
 * Plugin Name:   Bunzo
 * Plugin URI:    https://hasthemes.com/
 * Description:   This is some demo short description...
 * Version:       1.0.0
 * Author:        HasThemes
 * Author URI:    https://hasthemes.com/
 * Text Domain:   htbunzo
 * Domain Path:   /languages
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) exit;

// Include your custom code here.





/**
 * Developer Custom Code
 *
 * Developer Custom Code
 *
 * Developer Custom Code
 */

// Start Code for Set Post View Count
function wpb_set_post_views($postID) {
    $count_key = 'wpb_post_views_count';
    $count = get_post_meta($postID, $count_key, true);
    if($count==''){
        $count = 0;
        delete_post_meta($postID, $count_key);
        add_post_meta($postID, $count_key, '0');
    }else{
        $count++;
        update_post_meta($postID, $count_key, $count);
    }
}
//To keep the count accurate, lets get rid of prefetching
remove_action( 'wp_head', 'adjacent_posts_rel_link_wp_head', 10, 0);

add_action( 'graphql_register_types', function() {

    // This registers a connection to the Schema at the root of the Graph
    // The connection field name is "popularPosts"
    register_graphql_connection( [
        'fromType'           => 'RootQuery',
        'toType'             => 'Post',
        'fromFieldName'      => 'popularPosts', // This is the field name that will be exposed in the Schema to query this connection by
        'connectionTypeName' => 'RootQueryToPopularPostsConnection',
        'connectionArgs'     => \WPGraphQL\Connection\PostObjects::get_connection_args(), // This adds Post connection args to the connection
        'resolve'            => function( $root, $args, \WPGraphQL\AppContext $context, $info ) {

            $resolver = new \WPGraphQL\Data\Connection\PostObjectConnectionResolver( $root, $args, $context, $info );

            // Note, these args will override anything the user passes in as { where: { ... } } args in the GraphQL Query
            $resolver->set_query_arg( 'meta_key', 'wpb_post_views_count' );
            $resolver->set_query_arg( 'orderby', 'meta_value_num' );
            $resolver->set_query_arg( 'order', 'DESC' );

            return $resolver->get_connection();
        }
    ]);

    // This registers a field to the "Post" type so we can query the "viewCount" and see the value of which posts have the most views
    register_graphql_field( 'Post', 'viewCount', [
        'type'    => 'Int',
        'resolve' => function( $post ) {
            return get_post_meta( $post->databaseId, 'wpb_post_views_count', true );
        }
    ]);
    
    register_graphql_field( 'Post', 'viewCount', [
        'type'    => 'Int',
        'resolve' => function( $post ) {
            return get_post_meta( $post->databaseId, 'wpb_post_views_count', true );
        }
    ]);
    
    register_graphql_field( 'Post', 'video', [
        'type'    => 'String',
        'resolve' => function( $post ) {
            //$video_src = get_post_meta($post->databaseId, 'codeless_video_embed', true);
            //$video_src = get_post_meta( $post->databaseId, 'codeless_video_embed', true );
            return get_post_meta( $post->databaseId, 'codeless_video_embed', true );
        }
    ]);
    
    // This registers a field to the "Category" type so we can query the "thumbnail" and see the value of which categories
    register_graphql_field( 'Category', 'thumbnail', [
        'type'    => 'String',
        'resolve' => function( $get_category ) {
            $placehold = "https://place-hold.it/500x500.jpg&text=Thumbnail&fontsize=40";
            $image_id = get_term_meta ( $get_category->databaseId, 'category-image-id', true );
            return !empty( $image_id ) ? wp_get_attachment_url( $image_id ) : $placehold;
        }
    ]);
    

});



add_action('wp', function(){
    wpb_set_post_views(get_the_ID());
});
// End Code for Set Post View Count








//faqs post type start
add_action( 'init', function() {
   register_post_type( 'faqs', [
      'show_ui' => true,
      'labels'  => [
        'name' => 'Faqs',
        'add_new' => 'Add New Faq',
        'add_new_item' => 'Add New Faq',
      ],
      'public' => true,
      'show_in_graphql' => true,
      'hierarchical' => true,
      'graphql_single_name' => 'faq',
      'graphql_plural_name' => 'faqs',
   ] );
} );

//faqs post type end



///// Post Category Thumbnail Start /////
/**
 * Plugin class
 **/
if ( ! class_exists( 'CT_TAX_META' ) ) {

class CT_TAX_META {

  public function __construct() {
    //
  }
 
 /*
  * Initialize the class and start calling our hooks and filters
  * @since 1.0.0
 */
 public function init() {
   add_action( 'category_add_form_fields', array ( $this, 'add_category_image' ), 10, 2 );
   add_action( 'created_category', array ( $this, 'save_category_image' ), 10, 2 );
   add_action( 'category_edit_form_fields', array ( $this, 'update_category_image' ), 10, 2 );
   add_action( 'edited_category', array ( $this, 'updated_category_image' ), 10, 2 );
   add_action( 'admin_enqueue_scripts', array( $this, 'load_media' ) );
   add_action( 'admin_footer', array ( $this, 'add_script' ) );
 }

public function load_media() {
 wp_enqueue_media();
}
 
 /*
  * Add a form field in the new category page
  * @since 1.0.0
 */
 public function add_category_image ( $taxonomy ) { ?>
   <div class="form-field term-group">
     <label for="category-image-id"><?php _e('Image', 'hero-theme'); ?></label>
     <input type="hidden" id="category-image-id" name="category-image-id" class="custom_media_url" value="">
     <div id="category-image-wrapper"></div>
     <p>
       <input type="button" class="button button-secondary ct_tax_media_button" id="ct_tax_media_button" name="ct_tax_media_button" value="<?php _e( 'Add Image', 'hero-theme' ); ?>" />
       <input type="button" class="button button-secondary ct_tax_media_remove" id="ct_tax_media_remove" name="ct_tax_media_remove" value="<?php _e( 'Remove Image', 'hero-theme' ); ?>" />
    </p>
   </div>
 <?php
 }
 
 /*
  * Save the form field
  * @since 1.0.0
 */
 public function save_category_image ( $term_id, $tt_id ) {
   if( isset( $_POST['category-image-id'] ) && '' !== $_POST['category-image-id'] ){
     $image = $_POST['category-image-id'];
     add_term_meta( $term_id, 'category-image-id', $image, true );
   }
 }
 
 /*
  * Edit the form field
  * @since 1.0.0
 */
 public function update_category_image ( $term, $taxonomy ) { ?>
   <tr class="form-field term-group-wrap">
     <th scope="row">
       <label for="category-image-id"><?php _e( 'Image', 'hero-theme' ); ?></label>
     </th>
     <td>
       <?php $image_id = get_term_meta ( $term -> term_id, 'category-image-id', true ); ?>
       <input type="hidden" id="category-image-id" name="category-image-id" value="<?php echo $image_id; ?>">
       <div id="category-image-wrapper">
         <?php if ( $image_id ) { ?>
           <?php echo wp_get_attachment_image ( $image_id, 'thumbnail' ); ?>
         <?php } ?>
       </div>
       <p>
         <input type="button" class="button button-secondary ct_tax_media_button" id="ct_tax_media_button" name="ct_tax_media_button" value="<?php _e( 'Add Image', 'hero-theme' ); ?>" />
         <input type="button" class="button button-secondary ct_tax_media_remove" id="ct_tax_media_remove" name="ct_tax_media_remove" value="<?php _e( 'Remove Image', 'hero-theme' ); ?>" />
       </p>
     </td>
   </tr>
 <?php
 }

/*
 * Update the form field value
 * @since 1.0.0
 */
 public function updated_category_image ( $term_id, $tt_id ) {
   if( isset( $_POST['category-image-id'] ) && '' !== $_POST['category-image-id'] ){
     $image = $_POST['category-image-id'];
     update_term_meta ( $term_id, 'category-image-id', $image );
   } else {
     update_term_meta ( $term_id, 'category-image-id', '' );
   }
 }

/*
 * Add script
 * @since 1.0.0
 */
 public function add_script() { ?>
   <script>
     jQuery(document).ready( function($) {
       function ct_media_upload(button_class) {
         var _custom_media = true,
         _orig_send_attachment = wp.media.editor.send.attachment;
         $('body').on('click', button_class, function(e) {
           var button_id = '#'+$(this).attr('id');
           var send_attachment_bkp = wp.media.editor.send.attachment;
           var button = $(button_id);
           _custom_media = true;
           wp.media.editor.send.attachment = function(props, attachment){
             if ( _custom_media ) {
               $('#category-image-id').val(attachment.id);
               $('#category-image-wrapper').html('<img class="custom_media_image" src="" style="margin:0;padding:0;max-height:100px;float:none;" />');
               $('#category-image-wrapper .custom_media_image').attr('src',attachment.url).css('display','block');
             } else {
               return _orig_send_attachment.apply( button_id, [props, attachment] );
             }
            }
         wp.media.editor.open(button);
         return false;
       });
     }
     ct_media_upload('.ct_tax_media_button.button'); 
     $('body').on('click','.ct_tax_media_remove',function(){
       $('#category-image-id').val('');
       $('#category-image-wrapper').html('<img class="custom_media_image" src="" style="margin:0;padding:0;max-height:100px;float:none;" />');
     });
     
     $(document).ajaxComplete(function(event, xhr, settings) {
       var queryStringArr = settings.data.split('&');
       if( $.inArray('action=add-tag', queryStringArr) !== -1 ){
         var xml = xhr.responseXML;
         $response = $(xml).find('term_id').text();
         if($response!=""){
           // Clear the thumb image
           $('#category-image-wrapper').html('');
         }
       }
     });
   });
 </script>
 <?php }

  }
 
$CT_TAX_META = new CT_TAX_META();
$CT_TAX_META -> init();
 
}
// Post Category Thumbnail End




/////////// Video Post Start ////////
// Add the Page Meta Box
function codeless_add_custom_meta_box() {
    add_meta_box(
            'codeless_meta_box', // $id
            'Codeless Page Options', // $title 
            'codeless_show_custom_meta_box', // $callback
            'page', // $page
            'normal', // $context
            'high'); // $priority
}

add_action('add_meta_boxes', 'codeless_add_custom_meta_box');

// Add the Post Meta Box
function codeless_add_custom_post_meta_box() {
    add_meta_box(
            'codeless_meta_box', // $id
            'Codeless Page Options', // $title 
            'codeless_show_custom_post_meta_box', // $callback
            'post', // $post
            'normal', // $context
            'high'); // $priority
}

add_action('add_meta_boxes', 'codeless_add_custom_post_meta_box');

$prefix = 'codeless_';

// Field Array (Pages Meta)
$codeless_meta_fields = array();

// Field Array (Posts Meta)
$codeless_post_meta_fields = array(
    array(
        'label' => 'Featured Video Embed Code',
        'desc' => 'Paste your video code here to show a video instead of a featured image.',
        'id' => $prefix . 'video_embed',
        'type' => 'textarea'
    )
);

// The Callback for page meta box
function codeless_show_custom_meta_box() {
    global $codeless_meta_fields;
    codeless_show_page_meta_box($codeless_meta_fields);
}

// The Callback for post meta box
function codeless_show_custom_post_meta_box() {
    global $codeless_post_meta_fields;
    codeless_show_page_meta_box($codeless_post_meta_fields);
}

// The Callback
function codeless_show_page_meta_box($meta_fields) {

    global $post;
// Use nonce for verification
    echo '<input type="hidden" name="custom_meta_box_nonce" value="' . wp_create_nonce(basename(__FILE__)) . '" />';

    // Begin the field table and loop
    echo '<table class="form-table">';
    foreach ($meta_fields as $field) {
        // get value of this field if it exists for this post
        $meta = get_post_meta($post->ID, $field['id'], true);
        // begin a table row with
        echo '<tr>
        <th><label for="' . $field['id'] . '">' . $field['label'] . '</label></th>
        <td>';
        switch ($field['type']) {

            // text
            case 'text':
                echo '<input type="text" name="' . $field['id'] . '" id="' . $field['id'] . '" value="' . $meta . '" style="width:100%" />
                                                    <br /><span class="description">' . $field['desc'] . '</span>';
                break;

            // textarea
            case 'textarea':
                echo '<textarea style="width:100%" rows="2" id="' . $field['id'] . '" name="' . $field['id'] . '">' . $meta . '</textarea>
                                                    <br /><span class="description">' . $field['desc'] . '</span>';
                break;

            // checkbox
            case 'checkbox':
                echo '<input type="checkbox" name="' . $field['id'] . '" id="' . $field['id'] . '" ', $meta ? ' checked="checked"' : '', '/>
                                                    <label for="' . $field['id'] . '">' . $field['desc'] . '</label>';
                break;

            // select
            case 'select':
                echo '<select name="' . $field['id'] . '" id="' . $field['id'] . '">';
                foreach ($field['options'] as $option) {
                    echo '<option', $meta == $option['value'] ? ' selected="selected"' : '', ' value="' . $option['value'] . '">' . $option['label'] . '</option>';
                }
                echo '</select><br /><span class="description">' . $field['desc'] . '</span>';
                break;
        } //end switch
        echo '</td></tr>';
    } // end foreach
    echo '</table>'; // end table
}

// Save the Data
function codeless_save_custom_meta($post_id) {
    global $codeless_meta_fields;
    global $codeless_post_meta_fields;

    // verify nonce
    if (!wp_verify_nonce($_POST['custom_meta_box_nonce'], basename(__FILE__)))
        return $post_id;
    // check autosave
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE)
        return $post_id;
    // check permissions
    if ('page' == $_POST['post_type']) {
        if (!current_user_can('edit_page', $post_id))
            return $post_id;
    } elseif (!current_user_can('edit_post', $post_id)) {
        return $post_id;
    }

    //either post or page fields we'll be working with
    $fields;

    // Check permissions (pages or posts)
    if ('page' == $_POST['post_type']) {

        $fields = $codeless_meta_fields;
    } else if ('post' == $_POST['post_type']) {

        $fields = $codeless_post_meta_fields;
    }

    // loop through fields and save the data
    foreach ($fields as $field) {
        $old = get_post_meta($post_id, $field['id'], true);
        $new = $_POST[$field['id']];
        if ($new && $new != $old) {
            update_post_meta($post_id, $field['id'], $new);
        } elseif ('' == $new && $old) {
            delete_post_meta($post_id, $field['id'], $old);
        }
    } // end foreach
}

add_action('save_post', 'codeless_save_custom_meta');
////////// Video Post End /////////